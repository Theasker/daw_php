<?php
require_once './php-wsdl-2.3/class.phpwsdl.php';
PhpWsdl::RunQuickMode ( 'ServerW.php' ); // Archivo en el que están los métodos que queremos servir
?>
